const $=s=>document.querySelector(s),app=$("#app");let Q=[],byId={},T;
const rnd=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const MODES={mock:"Full mock",tech:"Technical",non:"Non-technical",subject:"Subject test",topic:"Topic test",wrong:"Previously wrong",due:"Due mistakes",weak:"Weak topics",bm:"Bookmarks",quick:"Quick practice",mixed:"Mixed practice",custom:"Custom test"};
const pct=(a,b)=>b?Math.round(a/b*100):0;
const bar=(l,v)=>`<div class=row><span>${l}</span><div class=bar2><i style="width:${v}%"></i></div><b>${v}%</b></div>`;
/* ---------- data + validation ---------- */
function validate(q,seen){const e=[];if(!q.id)e.push("missing id");else if(seen.has(q.id))e.push("duplicate id");seen.add(q.id);
 if(!Array.isArray(q.options)||q.options.length!=4||q.options.some(o=>!o))e.push("options");
 if(!(q.correctAnswer>=0&&q.correctAnswer<4))e.push("correctAnswer");if(!q.explanation)e.push("explanation");
 if(!["Easy","Medium","Hard"].includes(q.difficulty))e.push("difficulty");if(!q.subject)e.push("subject");return e}
async function load(){const seen=new Set();for(const f of DATA_FILES)for(const q of await (await fetch(f)).json()){const e=validate(q,seen);if(e.length){console.warn("Skipped",q.id,e);continue}Q.push(q);byId[q.id]=q}}
/* ---------- revision engine ---------- */
const isMis=id=>{const r=DB.att[id];return !!r&&r.wrong>0&&!r.hidden};
const mastered=id=>{const r=DB.att[id];return !!r&&r.wrong>0&&r.streak>=MASTERY_THRESHOLD};
const isDue=id=>isMis(id)&&!mastered(id);
function priority(q){const r=DB.att[q.id];if(!r)return 3+Math.random();if(r.wrong==0)return 1+Math.random();
 if(mastered(q.id))return .5+Math.random()*.1;const days=(Date.now()-r.last)/864e5;
 return 10+r.wrong*2-r.streak*3+Math.min(days,10)*.5}
function topicStats(){const t={};for(const id in DB.att){const q=byId[id];if(!q)continue;const r=DB.att[id],s=t[q.topic]||(t[q.topic]={a:0,c:0});s.a+=r.attempts;s.c+=r.correct}return t}
const weakTopics=()=>Object.entries(topicStats()).filter(([,s])=>s.a>=2&&pct(s.c,s.a)<WEAK_BELOW).map(x=>x[0]);
function build(o){if(o.ids)return o.ids.map(i=>byId[i]);
 let p=Q.filter(q=>q.exam.includes(o.exam));
 if(o.section)p=p.filter(q=>q.section==o.section);if(o.subject)p=p.filter(q=>q.subject==o.subject);if(o.topic)p=p.filter(q=>q.topic==o.topic);
 if(o.diff&&o.diff!="Mixed")p=p.filter(q=>q.difficulty==o.diff);
 if(o.mode=="wrong")p=p.filter(q=>isMis(q.id));if(o.mode=="due")p=p.filter(q=>isDue(q.id));
 if(o.mode=="weak"){const w=weakTopics();p=p.filter(q=>w.includes(q.topic))}if(o.mode=="bm")p=p.filter(q=>DB.bm.includes(q.id));
 const n=Math.min(o.count,p.length),s=p.map(q=>[priority(q),q]).sort((a,b)=>b[0]-a[0]).map(x=>x[1]);
 if(["wrong","due","weak","bm"].includes(o.mode))return rnd(s.slice(0,n));
 const due=s.filter(q=>isDue(q.id)).slice(0,Math.ceil(n*.4)),rest=s.filter(q=>!due.includes(q));
 return rnd([...due,...rnd(rest.slice(0,Math.max(n-due.length,0)*2)).slice(0,n-due.length)])}
/* ---------- test lifecycle ---------- */
function start(o){const qs=build(o);if(!qs.length)return alert("No questions match these settings yet.");
 const E=EXAMS[o.exam],mins=o.mins||Math.max(1,Math.round(E.duration*qs.length/E.total));
 DB.active={exam:o.exam,name:o.name||"Practice",ids:qs.map(q=>q.id),perm:Object.fromEntries(qs.map(q=>[q.id,rnd([0,1,2,3])])),ans:{},st:{},cur:0,mins,end:Date.now()+mins*6e4,sim:!!o.sim,sc:{c:E.correct,n:E.negative}};save();if(o.sim&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>{});exam()}
const quick=(mode,section="")=>start({exam:DB.exam,mode,section,count:50,diff:"Mixed",name:MODES[mode]});
const again=id=>start({exam:DB.exam,ids:[id],name:"Retry"});
const pc=(A,id)=>{const s=A.st[id]||{},a=A.ans[id]!=null;return a&&s.r?"ar":a?"a":s.r?"r":s.v?"na":"nv"};
function exam(){const A=DB.active;if(!A)return home();clearInterval(T);const id=A.ids[A.cur],q=byId[id];(A.st[id]=A.st[id]||{}).v=1;save();const sel=A.ans[id];
 app.innerHTML=`<header class=bar><b>${EXAMS[A.exam].name} · ${A.name}</b><span>Q ${A.cur+1} / ${A.ids.length}</span><span id=tm class=tm></span></header>
 <div class=ex><main class=card><p class=meta>${q.subject} · ${q.topic}</p><h2>${q.question}</h2>
 ${A.perm[id].map((o,k)=>`<label class="opt ${sel===o?"on":""}"><input type=radio name=o ${sel===o?"checked":""} onchange="pick(${o})"><b>${"ABCD"[k]}.</b> ${q.options[o]}</label>`).join("")}
 <div><button class=btn onclick="nav(-1)">Previous</button><button class="btn pri" onclick="nav(1)">Save &amp; Next</button><button class=btn onclick="mark()">Mark for Review &amp; Next</button><button class=btn onclick="clr()">Clear Response</button><button class=btn onclick="bm('${id}')">${DB.bm.includes(id)?"★ Bookmarked":"☆ Bookmark"}</button></div></main>
 <aside class=card><div class=pal>${A.ids.map((x,i)=>`<button class="p ${pc(A,x)} ${i==A.cur?"cur":""}" onclick="jump(${i})">${i+1}</button>`).join("")}</div>
 <p class=legend>Grey: not visited · Red: not answered · Green: answered · Purple: marked · Green+purple ring: answered &amp; marked</p>
 <button class="btn pri" style="width:100%" onclick="submit()">Submit Test</button></aside></div>`;
 tick();T=setInterval(tick,1000)}
function tick(){const A=DB.active;if(!A)return clearInterval(T);const r=Math.max(0,A.end-Date.now()),s=Math.ceil(r/1e3),el=$("#tm");
 if(el){el.textContent=[s/3600|0,s/60%60|0,s%60].map(x=>String(x).padStart(2,"0")).join(":");el.className="tm "+(r<3e5?"crit":r<6e5?"warn":"")}
 if(r<=0){clearInterval(T);alert("Time is up. Your test will be submitted.");finish()}}
const cur=()=>DB.active.ids[DB.active.cur];
function pick(o){DB.active.ans[cur()]=o;save();exam()}
function jump(i){DB.active.cur=i;exam()}function nav(d){const A=DB.active;A.cur=Math.min(A.ids.length-1,Math.max(0,A.cur+d));exam()}
function mark(){const s=DB.active.st[cur()];s.r=!s.r;nav(1)}function clr(){delete DB.active.ans[cur()];save();exam()}
function bm(id){const i=DB.bm.indexOf(id);i<0?DB.bm.push(id):DB.bm.splice(i,1);save();exam()}
function submit(){const A=DB.active,un=A.ids.filter(i=>A.ans[i]==null).length;if(confirm(`Submit the test now?\n${A.ids.length-un} answered, ${un} unanswered. You cannot change answers afterwards.`))finish()}
function finish(){const A=DB.active;if(!A)return;clearInterval(T);const now=Date.now();
 const r={date:now,exam:A.exam,name:A.name,total:A.ids.length,att:0,cor:0,wr:0,sub:{},sec:{},rows:[],sc:A.sc,time:Math.round(Math.min(A.mins*60,(now-(A.end-A.mins*6e4))/1e3))};
 A.ids.forEach(id=>{const q=byId[id],a=A.ans[id],rr=DB.att[id]||(DB.att[id]={attempts:0,correct:0,wrong:0,streak:0,last:0,sel:null});
  const s=r.sub[q.subject]||(r.sub[q.subject]={c:0,t:0}),c=r.sec[q.section]||(r.sec[q.section]={c:0,w:0}),row={id,sel:a,res:"U"};s.t++;
  if(a!=null){r.att++;rr.attempts++;rr.last=now;rr.sel=a;
   if(a==q.correctAnswer){r.cor++;s.c++;c.c++;rr.correct++;rr.streak++;row.res="C"}else{r.wr++;c.w++;rr.wrong++;rr.streak=0;rr.hidden=0;row.res="W"}}
  r.rows.push(row)});
 r.raw=r.cor*A.sc.c;r.neg=+(r.wr*A.sc.n).toFixed(2);r.score=+(r.raw-r.neg).toFixed(2);r.max=r.total*A.sc.c;
 DB.hist.push(r);DB.active=null;save();if(document.fullscreenElement)document.exitFullscreen();result(r)}
/* ---------- views ---------- */
function result(r){const acc=pct(r.cor,r.att),g={W:[],U:[],C:[]},lab={W:"Wrong",U:"Unattempted",C:"Correct"},ws=weakTopics();r.rows.forEach(x=>g[x.res].push(x));
 const st=[["Score",`${r.score} / ${r.max}`],["Accuracy",acc+"%"],["Attempted",`${r.att} / ${r.total}`],["Correct",r.cor],["Wrong",r.wr],["Unattempted",r.total-r.att],["Raw marks",r.raw],["Negative marks","−"+r.neg],["Time taken",Math.floor(r.time/60)+"m "+r.time%60+"s"],["Avg / question",Math.round(r.time/r.total)+"s"]];
 app.innerHTML=`<section class=card><h2>${EXAMS[r.exam].name} · ${r.name}</h2><div class=grid>${st.map(([a,b])=>`<div class=stat><small>${a}</small><b>${b}</b></div>`).join("")}</div>
 <h3>Section scores</h3>${Object.entries(r.sec).map(([k,v])=>`<p>${k}: <b>${+(v.c*r.sc.c-v.w*r.sc.n).toFixed(2)}</b> (${v.c} correct, ${v.w} wrong)</p>`).join("")}
 <h3>Subject-wise</h3>${Object.entries(r.sub).map(([k,v])=>bar(k,pct(v.c,v.t))).join("")}
 ${ws.length?`<h3>Weakest topics</h3><p>${ws.join(", ")}</p><button class="btn pri" onclick="quick('weak')">Practice Weak Topics</button>`:""}
 <button class=btn onclick="home()">Home</button><button class=btn onclick="quick('due')">Practice Due Mistakes</button></section>
 ${["W","U","C"].map(k=>`<section class=card><h3>${lab[k]} (${g[k].length})</h3>${g[k].map(x=>{const q=byId[x.id];return `<div class="rv ${k}"><p class=meta>${q.subject} · ${q.topic} · ${q.difficulty}</p><p><b>${q.question}</b></p>
 <p>Your answer: ${x.sel==null?"—":q.options[x.sel]}<br>Correct answer: ${q.options[q.correctAnswer]}</p><p>${q.explanation}</p>${q.formula?`<p><i>Formula:</i> ${q.formula}</p>`:""}<p class=meta>Concept: ${q.concept}</p><button class=btn onclick="again('${q.id}')">Practice this question again</button></div>`}).join("")||"<p class=meta>None</p>"}</section>`).join("")}`}
function stats(){let a=0,c=0;for(const id in DB.att){a+=DB.att[id].attempts;c+=DB.att[id].correct}const ids=Object.keys(DB.att).filter(i=>byId[i]);
 return{a,acc:pct(c,a),tests:DB.hist.length,due:ids.filter(isDue).length,mis:ids.filter(isMis).length,mas:ids.filter(mastered).length,best:DB.hist.length?Math.max(...DB.hist.map(h=>pct(h.score,h.max))):0}}
function home(){clearInterval(T);const s=stats(),w=weakTopics();
 app.innerHTML=`${DB.active?`<section class=card><b>A test is in progress.</b> <button class="btn pri" onclick="exam()">Resume test</button></section>`:""}
 <section class=card><h2>Choose exam</h2>${Object.entries(EXAMS).map(([k,v])=>`<button class="btn ${k==DB.exam?"on":""}" onclick="DB.exam='${k}';save();home()">${v.name}</button>`).join("")}
 <p class=meta>Marking: +${EXAMS[DB.exam].correct} / −${+EXAMS[DB.exam].negative.toFixed(3)} · ${EXAMS[DB.exam].duration} min for ${EXAMS[DB.exam].total} questions (editable placeholder)</p></section>
 <section class=card><div class=grid>${[["Accuracy",s.acc+"%"],["Questions solved",s.a],["Tests completed",s.tests],["Revision due",s.due],["Best score",s.best+"%"],["Weak topics",w.length]].map(([a,b])=>`<div class=stat><small>${a}</small><b>${b}</b></div>`).join("")}</div>${w.length?`<p>Weak: ${w.join(", ")}</p>`:""}</section>
 <section class=card><h3>Practice</h3><button class="btn pri" onclick="setup({mode:'mock'})">Full Mock Test</button><button class=btn onclick="setup({mode:'tech'})">Technical</button><button class=btn onclick="setup({mode:'non'})">Non-Technical</button><button class=btn onclick="setup({})">Custom Test</button><button class=btn onclick="quick('quick')">Quick Practice</button><button class=btn onclick="quick('bm')">Bookmarks</button><button class=btn onclick="mistakes()">My Mistakes</button><button class=btn onclick="perf()">Performance</button></section>
 <section class=card><h3>Your data</h3><button class=btn onclick="exp()">Export My Progress</button><label class=btn style="display:inline-flex;align-items:center">Import My Progress<input type=file hidden accept=.json onchange="imp(this.files[0])"></label>
 <button class="btn danger" onclick="reset('hist')">Reset Test History</button><button class="btn danger" onclick="reset('att')">Reset Wrong Questions</button><button class="btn danger" onclick="reset('bm')">Reset Bookmarks</button><button class="btn danger" onclick="reset('all')">Reset Everything</button></section>`}
function setup(p){const subs=[...new Set(Q.map(q=>q.subject))],tops=[...new Set(Q.map(q=>q.topic))],o=(a,s)=>a.map(x=>`<option ${x==s?"selected":""}>${x}</option>`).join("");
 app.innerHTML=`<section class=card><h2>Build a test</h2><div class=form>
 <label>Exam<select id=fe>${Object.entries(EXAMS).map(([k,v])=>`<option value=${k} ${k==DB.exam?"selected":""}>${v.name}</option>`).join("")}</select></label>
 <label>Mode<select id=fm>${Object.entries(MODES).map(([k,v])=>`<option value=${k} ${k==p.mode?"selected":""}>${v}</option>`).join("")}</select></label>
 <label>Subject<select id=fs><option>Any</option>${o(subs)}</select></label><label>Topic<select id=ft><option>Any</option>${o(tops)}</select></label>
 <label>Questions<input id=fc type=number min=1 value=10 list=cl></label><datalist id=cl><option>10<option>25<option>50<option>100<option>150</datalist>
 <label>Difficulty<select id=fd>${o(["Mixed","Easy","Medium","Hard"])}</select></label><label>Minutes (blank = auto)<input id=fn type=number min=1></label>
 <label>Exam simulation<select id=sim><option value=0>Off</option><option value=1>On (fullscreen, leave-page warning)</option></select></label></div>
 <button class="btn pri" onclick="go2()">Start test</button><button class=btn onclick="home()">Back</button></section>`}
function go2(){const v=i=>$("#"+i).value,m=v("fm"),E=EXAMS[v("fe")];DB.exam=v("fe");
 start({exam:v("fe"),mode:m,count:m=="mock"?E.total:+v("fc")||10,diff:v("fd"),subject:v("fs")=="Any"?"":v("fs"),topic:v("ft")=="Any"?"":v("ft"),mins:+v("fn")||0,sim:v("sim")=="1",name:MODES[m],section:m=="tech"?"Technical":m=="non"?"Non-Technical":""})}
function mistakes(){const s=stats(),ids=Object.keys(DB.att).filter(i=>byId[i]&&isMis(i));
 app.innerHTML=`<section class=card><h2>My Mistakes</h2><div class=grid>${[["Total mistakes",s.mis],["Due for revision",s.due],["Mastered",s.mas],["Weak (≥2 wrong)",ids.filter(i=>DB.att[i].wrong>=2&&!mastered(i)).length]].map(([a,b])=>`<div class=stat><small>${a}</small><b>${b}</b></div>`).join("")}</div>
 <p class=meta>Mastered = ${MASTERY_THRESHOLD} correct answers in a row, in separate tests.</p>
 <button class="btn pri" onclick="quick('wrong')">Practice All Mistakes</button><button class=btn onclick="quick('due')">Practice Due Mistakes</button><button class=btn onclick="quick('wrong','Technical')">Technical Mistakes</button><button class=btn onclick="quick('wrong','Non-Technical')">Non-Technical Mistakes</button>
 <button class=btn onclick="clearMastered()">Clear Mastered Questions</button><button class=btn onclick="home()">Home</button></section>
 <section class=card>${ids.map(i=>{const r=DB.att[i];return `<p><b>${i}</b> ${byId[i].topic} — wrong ${r.wrong}, correct ${r.correct}, streak ${r.streak}/${MASTERY_THRESHOLD}${mastered(i)?" ✓ mastered":""}</p>`}).join("")||"<p class=meta>No mistakes recorded yet. Take a test to start.</p>"}</section>`}
function clearMastered(){Object.keys(DB.att).filter(mastered).forEach(i=>DB.att[i].hidden=1);save();mistakes()}
function perf(){const h=DB.hist.slice(-15);app.innerHTML=`<section class=card><h2>Performance trend</h2>${h.map((x,i)=>bar(`Test ${DB.hist.length-h.length+i+1} score`,Math.max(0,pct(x.score,x.max)))+bar("accuracy",pct(x.cor,x.att))+bar("attempted",pct(x.att,x.total))+`<p class=meta>Time ${Math.round(x.time/60)} min · ${Math.round(x.time/x.total)}s per question</p>`).join("")||"<p class=meta>No tests yet.</p>"}
 <h3>Topic accuracy</h3>${Object.entries(topicStats()).map(([t,s])=>bar(t+(pct(s.c,s.a)<WEAK_BELOW?" (weak)":pct(s.c,s.a)>STRONG_ABOVE?" (strong)":""),pct(s.c,s.a))).join("")}<button class=btn onclick="home()">Home</button></section>`}
/* ---------- data tools ---------- */
function exp(){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(DB)],{type:"application/json"}));a.download="cbt-progress.json";a.click()}
function imp(f){if(!f)return;f.text().then(t=>{try{Object.assign(DB,JSON.parse(t));save();home();alert("Progress imported.")}catch{alert("That file is not a valid progress export.")}})}
function reset(w){if(prompt("This cannot be undone. Type RESET to continue.")!=="RESET")return;
 if(w=="hist")DB.hist=[];if(w=="att")DB.att={};if(w=="bm")DB.bm=[];if(w=="all"){DB.hist=[];DB.att={};DB.bm=[];DB.active=null}save();home()}
function theme(){DB.theme=DB.theme=="dark"?"light":"dark";document.documentElement.dataset.theme=DB.theme;save()}
addEventListener("beforeunload",e=>{if(DB.active){e.preventDefault();e.returnValue=""}});
document.documentElement.dataset.theme=DB.theme;
$("#nv").innerHTML=`<button onclick="home()">Home</button><button onclick="mistakes()">Mistakes</button><button onclick="perf()">Performance</button><button onclick="theme()">Light/Dark</button>`;
load().then(()=>DB.active?exam():home()).catch(e=>app.innerHTML=`<section class=card>Could not load questions (${e.message}). Serve the folder over HTTP, for example GitHub Pages or <code>python3 -m http.server</code>.</section>`);
