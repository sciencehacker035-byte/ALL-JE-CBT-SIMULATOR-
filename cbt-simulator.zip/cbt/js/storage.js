const KEY="cbt_v1";
const DB=Object.assign({att:{},hist:[],bm:[],active:null,theme:"light",exam:"RRB_JE"},(()=>{try{return JSON.parse(localStorage.getItem(KEY))}catch{return{}}})()||{});
const save=()=>localStorage.setItem(KEY,JSON.stringify(DB));
