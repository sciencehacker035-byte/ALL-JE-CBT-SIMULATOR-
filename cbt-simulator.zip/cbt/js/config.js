// PLACEHOLDER exam patterns – NOT verified. Check the latest official notification and edit these values.
const EXAMS={
 RRB_JE:{name:"RRB JE",duration:120,total:100,correct:1,negative:1/3},
 SSC_JE:{name:"SSC JE",duration:120,total:100,correct:1,negative:1/3},
 HPCL_JE:{name:"HPCL Junior Executive",duration:120,total:100,correct:1,negative:1/4}
};
const MASTERY_THRESHOLD=3;      // consecutive correct answers (in separate tests) after a mistake
const WEAK_BELOW=50, STRONG_ABOVE=75;
const DATA_FILES=["data/questions.json"]; // add more files here as the bank grows
